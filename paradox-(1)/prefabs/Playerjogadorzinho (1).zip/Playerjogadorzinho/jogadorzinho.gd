extends CharacterBody2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0

# Estas variáveis aparecerão no seu Inspector. 
# Você pode mudar os nomes aqui para corresponder aos que você criou no Input Map.
@export var action_left = "ui_left"
@export var action_right = "ui_right"
@export var action_jump = "ui_accept"
@export var action_attack = "ui_select"

@onready var anim = $AnimatedSprite2D 

func _physics_process(delta):
	# Gravidade
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Pulo (Usa a ação definida no Inspector)
	if Input.is_action_just_pressed(action_jump) and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Movimento (Usa as ações definidas no Inspector)
	var direction = Input.get_axis(action_left, action_right)
	
	if direction != 0:
		velocity.x = direction * SPEED
		anim.play("walk")
		anim.flip_h = (direction < 0)
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		# Só toca o idle se não estiver atacando
		if anim.animation != "attack":
			anim.play("idle")

	# Ataque (Usa a ação definida no Inspector)
	if Input.is_action_just_pressed(action_attack):
		anim.play("attack")

	move_and_slide()
